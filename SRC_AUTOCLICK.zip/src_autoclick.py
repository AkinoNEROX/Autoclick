
import requests
import win32api
import win32con
import keyboard
import pyautogui
import time

print('#####################################################')
print('')
print('AutoClick Monify By Akino')
print('Facebook: https://www.facebook.com/AkinoGuard/')
print('')
print('#####################################################')
print('')
print('')
print('Wait 5 SEC !!!!!')

Time = 0
RemapNub = 0 
START_GAMENub = 0
ScreenShotNub = 0
RemapNub = 0 
HeroNub = 0


def linenotify(message):
  url = 'https://notify-api.line.me/api/notify'
  token = 'GrwJNZzdX8Tb1xac5qWLWtlvTbdf2vf8nsED0bMvWv5' # Line Notify Token
  img = {'imageFile': open('my_screenshot.png','rb')} 
  data = {'message': message}
  headers = {'Authorization':'Bearer ' + token}
  session = requests.Session()
  session_post = session.post(url, headers=headers, files=img, data =data)
  print(session_post.text) 






def RestartMap():
    global RemapNub
    global START_GAMENub
    global ScreenShotNub
    print('STARTGAME')
    position = pyautogui.locateOnScreen('img/play.png')
    checklogin = pyautogui.locateOnScreen('img/connect.png')
    position3 = pyautogui.locateOnScreen('img/connect2.png')

    if position3 is not None:
        Connect()
    if checklogin is not None:
        pyautogui.moveTo(checklogin)
        click()
        Connect()
    if position is not None:
        pyautogui.moveTo(position)
        click()
        return RestartMap()
    
    if position == None:
        time.sleep(60)
        RemapNub = RemapNub + 1
        START_GAMENub = START_GAMENub + 1
        ScreenShotNub = ScreenShotNub + 1
        print('Resetmap '+str(START_GAMENub))
        if START_GAMENub >= 53: # เวลา restart hero
            RestartMap2()

        if ScreenShotNub >= 2000000: #เวลาถ่ายรูปหน้าจอ
            ScreenShotNub = 0
            ScreenShot()


        if RemapNub >= 5: #เวลารีแมพ
            RemapNub = 0
            RestartMap2()
        else: 
            return RestartMap()


def RestartMap2():
    global RemapNub
    global START_GAMENub
    position = pyautogui.locateOnScreen('img/butt.png')
    if position is not None:
        pyautogui.moveTo(position)
        click()
        return RestartMap2()
    if position == None:
        if START_GAMENub >= 57:
            START_GAMENub = 0
            START_GAME()
        else:
            RestartMap()
    
def START_GAME():
    print('STARTHERO')
    position = pyautogui.locateOnScreen('img/Hero.png')

    if position is not None:
        pyautogui.moveTo(position)
        click()
        return START_GAME()
    if position == None:
        START_ALL()



def START_ALL():
    position = pyautogui.locateOnScreen('img/all.png')

    if position is not None:
        pyautogui.moveTo(position)
        click()
        return START_ALL()
    if position == None:
        OUT_ALL()

def OUT_ALL():
    position = pyautogui.locateOnScreen('img/outall.png')
    if position is not None:
        pyautogui.moveTo(position)
        click()
        return OUT_ALL()
    if position == None:
       RestartMap()


def click():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)

def OUT_CHECK():
    position = pyautogui.locateOnScreen('img/outcheck.png')
    if position is not None:
        pyautogui.moveTo(position)
        click()
        return OUT_CHECK()
    if position == None:
        RestartMap()


def ScreenShot():
    print('#####################################################')
    print('ScreenShot @@@ <>=====')
    position = pyautogui.locateOnScreen('img/checkwalllet.png')
    if position is not None:
        pyautogui.moveTo(position)
        click()
        return ScreenShot()
    if position == None:
        im1 = pyautogui.screenshot()
        im2 = pyautogui.screenshot('my_screenshot.png')
        time.sleep(3)
        linenotify('Bobmbcrypto : เหรียญที่ได้')
        OUT_CHECK()




START_GAME()

